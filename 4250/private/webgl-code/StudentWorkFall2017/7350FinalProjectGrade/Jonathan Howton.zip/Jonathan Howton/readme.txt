Jonathan Howton
CSCI 6350 - Data Mining
Spring 2017
Final Project
readme.txt



Jupyter notebooks were used in this project.

The order of the notebooks:
    1. Preprocess.ipynb
    2. Preprocessing_2.ipynb
    3.   The folowing in any order:
        'RandomForest Analysis.ipynb'
         PCA.ipynb

The starting data file used was '2009HMDALAR - National.CSV' 

This file is 3.3GB, so it could not be uploaded to dropbox. It can be downloaded from :
	http://www.ffiec.gov/hmdarawdata/LAR/National/2009HMDALAR%20-%20National.zip. 

All intermediate files are generated if notebooks are run in correct order with the correct starting file.

