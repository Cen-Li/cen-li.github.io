from io import StringIO
import pandas as pd
import sys

textFile = '/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal/textFeatures_1000.csv'
numericFile = '/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal/numericFeatures.csv'


# ############################################## #
# Load files
# ############################################## #

df_num = pd.read_csv(numericFile)
df_text = pd.read_csv(textFile)
#print('Files Loaded')

# Size of first dataset:    10000 x 34394
# Size of modified dataset: 10000 x 2000

# k-means would not converge after running for a full day
# To fix this we use only the top 1000 most commonly occuring
# word stems for question and answer

# ############################################## #
# Feature Selection Step
# ############################################## #

df_num = df_num[[
	'Id',
	'AnswerScore',
	'QuestionScore',
	'AvgCurrentScore',
	'NumCurrentAnswers',
	'NumCodeSnippets',
	'AnswerBodyWordCount'
]]


# ############################################## #
# Cluster with k-means
# ############################################## #
from sklearn.cluster import KMeans
from sklearn.model_selection import cross_val_predict
from sklearn import linear_model

lr = linear_model.LinearRegression()
kmeans = KMeans()
numTrials = 1000
numClusters = 10

for t in range(1,numTrials+1):
    for k in range(1,numClusters+1):
        #k=10
        sse = 0
        label_counts = []
        for i in range(k):
            label_counts.append(0)

        while( 0 in label_counts or 1 in label_counts ):
            kmeans = KMeans(n_clusters=k, init='k-means++', n_init=1, random_state=t).fit(df_text.ix[:,df_text.columns != 'Id'])

            # Get label counts
            for i in range(k):
                label_counts[i] = 0

            for i in kmeans.labels_:
                label_counts[i] += 1

        # ############################################## #
        # For each cluster, use linear regression on 
        # numeric attributes to predict score
        # ############################################## #

        for i in range(k):
        #i = 0 # just try this to start with
            X = df_num.drop(['Id','AnswerScore'],axis=1).iloc[[j for j in range(len(kmeans.labels_)) if kmeans.labels_[j]==i],:]
            y = df_num.iloc[[j for j in range(len(kmeans.labels_)) if kmeans.labels_[j]==i],df_num.columns == 'AnswerScore']
            predicted = cross_val_predict(lr, X, y, cv=10 if label_counts[i] > 100 else 2)
            sse += sum(((y-predicted)**2).values)[0]

        sys.stdout.write(str(sse / df_text.shape[0])) # Mean squared error
        if( k != numClusters ):
            sys.stdout.write(',')

    sys.stdout.write('\n')
