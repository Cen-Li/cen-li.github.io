from io import StringIO
from nltk import word_tokenize
from nltk.corpus import stopwords
from nltk.stem.lancaster import LancasterStemmer
import pandas as pd
import re

answerFile = '/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal/originals/Answers.csv'
outFile = '/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal/answerFeatures_100.csv'


# ############################################## #
# Load questions file
# ############################################## #

df_answer = pd.read_csv(StringIO(open(answerFile,encoding='latin-1').read().encode('latin-1').decode('utf-8',errors='ignore')),nrows=10000)
df_answer = df_answer[['Id','ParentId','Body']]
df_stems = df_answer[['Id','ParentId']]


# ############################################## #
# Do word counting
# ############################################## #

## Remove contents of <code> tags
## Remove html tags
## Remove punctuation
## Create bag of words
def makeStems(x):
    clean_body = TAG_RE.sub(' ',TAG_CODE.sub(' ', x)).translate(t).split()
    clean_body = [st.stem(w) for w in clean_body if (len(w) > 2 and len(w) < 20 and w not in stopwords.words('english'))]
    for w in clean_body:
        if 'a_'+w not in df_stems.columns:
            df_stems['a_'+w] = 0

def countStems(x):
    clean_body = TAG_RE.sub(' ',TAG_CODE.sub(' ', x['Body'])).translate(t).split()
    clean_body = [st.stem(w) for w in clean_body if (len(w) > 2 and len(w) < 20 and w not in stopwords.words('english'))]
    for w in clean_body:
        df_stems.loc[df_stems['Id'] == x['Id'],'a_'+w] += 1

## These variables are all used in the 'makeStems' and 'countStems' functions
TAG_RE = re.compile(r'<[^>]+>')
TAG_CODE = re.compile(r'<code.*?</code>')
t = str.maketrans('','','\n\t,.!;:{}[]<>\/\@#$%^&*()-_=+?\'\"1234567890`~')
st = LancasterStemmer()

df_answer['Body'].apply(makeStems)
df_answer.apply(countStems,axis=1)

## Get number of rows in which each stem occurs
sr_stems = df_stems.apply(lambda x: (x>0).sum(), axis=0).drop('Id')
sr_stems.sort_values(inplace=True,ascending=False)

## Only use most common 1000 stems
items = list(sr_stems[0:100].axes[0])
items.insert(0,'Id')


# ############################################## #
# Extract final dataset
# ############################################## #
df_out = df_stems[items]

# Normalize
df_out.iloc[:,2:] = df_out.iloc[:,2:].apply(lambda x: x - x.mean() / (x.max() - x.min()), axis=0)

# Export
df_out.to_csv(outFile,index=False)

