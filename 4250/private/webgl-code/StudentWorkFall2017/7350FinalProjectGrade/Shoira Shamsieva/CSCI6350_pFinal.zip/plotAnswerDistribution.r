setwd('/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal')

df <- read.csv('numericFeatures.csv')
hist(df[['AnswerScore']],main='All Answer Score Frequency',xlab='Answer Score',col=2,breaks=100)
boxplot(df[['AnswerScore']])

df2 <- df[df$AnswerScore < 100,"AnswerScore"]
hist(df2,main='Answer Score < 100 Frequency',xlab='Answer Score',col=2)
