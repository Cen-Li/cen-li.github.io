from io import StringIO
import pandas as pd

questionFile = '/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal/questionFeatures_100.csv'
answerFile = '/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal/answerFeatures_100.csv'
tempFile = '/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal/textFeaturesTemp.csv'
outFile = '/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal/textFeatures_100.csv'


# ############################################## #
# Load files
# ############################################## #

## used for answer only results
#df_answer = pd.read_csv(answerFile)
#df_answer = df_answer.drop('ParentId',axis=1)
#df_answer.to_csv(outFile,index=False)

df_question = pd.read_csv(questionFile)
df_answer = pd.read_csv(answerFile)
df_answer = pd.merge(df_question,df_answer,left_on='Id',right_on='ParentId')
#df_answer = df_answer.drop('Id_x',axis=1)
#df_answer = df_answer.drop('ParentId',axis=1)
#df_answer.rename(columns={'Id_y':'Id'},inplace=True)

## The dataset is so large that it can't be manipulated in memory at this point,
## so we have to go through line by line to remove unwanted columns

## export
df_answer.to_csv(tempFile,index=False)

## Remove unneeded columns 
f_in = open(tempFile,'r')
f_out = open(outFile,'w')

line = f_in.readline()
items = line.split(',')
ix_idy = items.index('Id_y')
ix_idx = items.index('Id_x')
ix_pid = items.index('ParentId')

items[ix_idy] = 'Id'
del items[ix_idx]
del items[ix_pid]
f_out.write(','.join(items).rstrip() + '\n')

line = f_in.readline()
while(line != '' ):
    items = line.split(',')
    del items[ix_idx]
    del items[ix_pid]
    f_out.write(','.join(items).rstrip() + '\n')
    line = f_in.readline()

f_out.close()
