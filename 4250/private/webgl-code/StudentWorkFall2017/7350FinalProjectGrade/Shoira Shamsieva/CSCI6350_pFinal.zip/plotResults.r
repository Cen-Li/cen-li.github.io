library(ggplot2)
setwd('/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal')

df <- read.csv('results_1000.csv',header=FALSE)
df_fs <- read.csv('results_fs_1000.csv',header=FALSE)
means <- apply(df,2,mean)
means_fs <- apply(df_fs,2,mean)
df_means <- data.frame(x=1:10,all=means,fs=means_fs)

ggplot(df_means,aes(x))+geom_line(aes(y=all,color="All")) +
    geom_line(aes(y=fs,color="Reduced")) +
    labs(color="Feature Set") +
    ggtitle("Prediction Results") +
    labs(x="Number of Clusters",y="Average Mean Squared Error Per Trial (1000 Trials)") +
    scale_x_continuous(breaks=1:10)
