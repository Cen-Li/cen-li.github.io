from io import StringIO
import re
import numpy as np
import pandas as pd

questionFile = '/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal/originals/Questions.csv'
answerFile = '/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal/originals/Answers.csv'
tagFile = '/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal/originals/Tags.csv'
outFile = '/media/yorg/Data/Classes/MTSU/CSCI6350/pFinal/numericFeatures.csv'


# ############################################## #
# Load answers file
# ############################################## #

# Some inititial preprocessing steps:
# Encoding had to be changed from latin to utf-8
# Some lines caused errors, so these were ignored
df_answer = pd.read_csv(StringIO(open(answerFile,encoding='latin-1').read().encode('latin-1').decode('utf-8',errors='ignore')))
#>>> df_answer.columns
#Index(['Id', 'OwnerUserId', 'CreationDate', 'ParentId', 'Score', 'Body'], dtype='object')


# ############################################## #
# Add NumQuestionsAnswered
# ############################################## #

# Get average score for users
# Datatype for this is 'Series' not 'DataFrame'
sr_t1 = df_answer.groupby('OwnerUserId').size()

# Add result back into the full dataset
# Some OwnerUserIds are input as NA, so we mark AvgAnswerUserScore as zero for these
# Must flatten numpy array created by aggregate function
df_answer = pd.merge(df_answer,pd.DataFrame({'OwnerUserId':sr_t1.index,'NumQuestionsAnswered':sr_t1.values.flatten()}),on='OwnerUserId',how='outer').fillna(0)

# Example of results (first 20 rows):
df_answer[['ParentId','Id','OwnerUserId','NumQuestionsAnswered']].sort_values(by=['ParentId','Id'])[0:19]

del sr_t1


# ############################################## #
# Add AvgAnswerUserScore
# ############################################## #

# Get average score for users
# Datatype for this is 'Series' not 'DataFrame'
#sr_t1 = df_answer.groupby('OwnerUserId').agg({'Score':np.mean})

# Add result back into the full dataset
# Some OwnerUserIds are input as NA, so we mark AvgAnswerUserScore as zero for these
# Must flatten numpy array created by aggregate function
#df_answer = pd.merge(df_answer,pd.DataFrame({'OwnerUserId':sr_t1.index,'AvgAnswerUserScore':sr_t1.values.flatten()}),on='OwnerUserId',how='outer').fillna(0)

# Example of results (first 20 rows):
#df_answer[['ParentId','Id','OwnerUserId','AvgAnswerUserScore']].sort_values(by=['ParentId','Id'])[0:19]

#del sr_t1

# ############################################## #
# Add AvgCurrentScore
# ############################################## #

# Create dataframe for subset
df_t1 = df_answer[['Id','ParentId','CreationDate','Score']]

# Merge is equivalent to SQL join
df_t1 = pd.merge(df_t1,df_t1,on='ParentId')

# Get average score at time of answer
sr_t1 = df_t1[df_t1['CreationDate_y'] <  df_t1['CreationDate_x']].groupby('Id_x').agg({'Score_y':np.mean})

# Add result back into the full dataset
df_answer = pd.merge(df_answer,pd.DataFrame({'Id':sr_t1.index,'AvgCurrentScore':sr_t1.values.flatten()}),on='Id',how='outer').fillna(0)

# Example of results (first 20 rows):
df_answer[['ParentId','Id','Score','AvgCurrentScore']].sort_values(by=['ParentId','Id'])[0:19]

del sr_t1

# ############################################## #
# Add NumCurrentAnswers
# ############################################## #

# Get number of responses that already existed at time of answer
sr_t1 = df_t1[df_t1['CreationDate_y'] <  df_t1['CreationDate_x']].groupby('Id_x').size()

# Add result back into the full dataset
df_answer = pd.merge(df_answer,pd.DataFrame({'Id':sr_t1.index,'NumCurrentAnswers':sr_t1.values}),on='Id',how='outer').fillna(0)

# Example of sorted results (first 20 rows):
df_answer[['ParentId','Id','NumCurrentAnswers']].sort_values(by=['ParentId','Id'])[0:19]

del df_t1
del sr_t1

# ############################################## #
# Add NumLinks
# ############################################## #

# NOTE: this isn't perfect because links inside <code> tags are counted as actual links
df_answer['NumLinks'] = df_answer['Body'].apply(lambda x: x.count('<a'))

# Example of results (first 20 rows):
df_answer[['Id','Body','NumLinks']].sort_values(by=['Id'])[0:19]


# ############################################## #
# Add NumCodeSnippets
# ############################################## #

df_answer['NumCodeSnippets'] = df_answer['Body'].apply(lambda x: x.count('<code'))

# Example of results (first 20 rows):
df_answer[['Id','Body','NumCodeSnippets']].sort_values(by=['Id'])[0:19]


# ############################################## #
# Add AnswerBodyWordCount
# ############################################## #

# Remove html tags
# Convert \n to space
TAG_RE = re.compile(r'<[^>]+>')
df_answer['AnswerBodyWordCount'] = df_answer['Body'].apply(lambda x: len(TAG_RE.sub('', x).replace('\n',' ').split()))

# Example of results (first 20 rows):
df_answer[['Id','AnswerBodyWordCount']].sort_values(by=['Id'])[0:19]


# ############################################## #
# Load questions file
# ############################################## #

df_question = pd.read_csv(StringIO(open(questionFile,encoding='latin-1').read().encode('latin-1').decode('utf-8',errors='ignore')))
# >>> df_question.columns
# Index(['Id', 'OwnerUserId', 'CreationDate', 'Score', 'Title', 'Body'], dtype='object')


# ############################################## #
# Add QuestionScore
# ############################################## #

df_t1 = pd.merge(df_question[['Id','Score']],df_answer[['Id','ParentId']],left_on='Id',right_on='ParentId')
df_answer = pd.merge(df_answer,pd.DataFrame({'Id':df_t1['Id_y'],'QuestionScore':df_t1['Score']}),on='Id',how='outer').fillna(0)

# Example of results (first 20 rows):
df_answer[['ParentId','Id','QuestionScore']].sort_values(by=['ParentId','Id'])[0:19]

del df_t1


# ############################################## #
# Add AvgQuestionUserScore
# ############################################## #

# Get average score for users
# Datatype for this is 'Series' not 'DataFrame'
sr_t1 = df_question.groupby('OwnerUserId').agg({'Score':np.mean})

# Add result back into the full dataset
# Some OwnerUserIds are input as NA, so we mark AvgAnswerUserScore as zero for these
# Must flatten numpy array created by aggregate function
df_question = pd.merge(df_question,pd.DataFrame({'OwnerUserId':sr_t1.index,'AvgQuestionUserScore':sr_t1.values.flatten()}),on='OwnerUserId',how='outer').fillna(0)

# Example of results (first 20 rows):
df_question[['Id','OwnerUserId','AvgQuestionUserScore']].sort_values(by=['Id'])[0:19]

del sr_t1

# ############################################## #
# Add QuestionBodyWordCount
# ############################################## #

# Remove html tags
# Convert \n to space
df_question['QuestionBodyWordCount'] = df_question['Body'].apply(lambda x: len(TAG_RE.sub('', x).replace('\n',' ').split()))

# Example of results (first 20 rows):
df_question[['Id','QuestionBodyWordCount']].sort_values(by=['Id'])[0:19]


# ############################################## #
# Add TimeElapsed
# ############################################## #

df_t1 = pd.merge(df_question[['CreationDate','Id']],df_answer[['CreationDate','ParentId','Id']],left_on='Id',right_on='ParentId')
df_answer['TimeElapsed'] = (pd.to_datetime(df_t1['CreationDate_y']) - pd.to_datetime(df_t1['CreationDate_x'])).astype('timedelta64[s]')

# Example
# Check this - not cleaning up old variables can cause bad values here
df_answer[df_answer['ParentId']==469][['Id','CreationDate','TimeElapsed']]

del df_t1


# ############################################## #
# Extract final dataset
# ############################################## #

df_answer = pd.merge(df_question[['Id','AvgQuestionUserScore','QuestionBodyWordCount']],df_answer,left_on='Id',right_on='ParentId')

df_num = pd.DataFrame({
    'NumQuestionsAnswered':df_answer['NumQuestionsAnswered'],
    #'AvgAnswerUserScore':df_answer['AvgAnswerUserScore'],
    'AvgCurrentScore':df_answer['AvgCurrentScore'],
    'NumCurrentAnswers':df_answer['NumCurrentAnswers'],
    'NumLinks':df_answer['NumLinks'],
    'NumCodeSnippets':df_answer['NumCodeSnippets'],
    'AnswerBodyWordCount':df_answer['AnswerBodyWordCount'],
    'QuestionScore':df_answer['QuestionScore'],
    'TimeElapsed':df_answer['TimeElapsed'],
    'AvgQuestionUserScore':df_answer['AvgQuestionUserScore'],
    'QuestionBodyWordCount':df_answer['QuestionBodyWordCount']
})

# Normalize
df_num = (df_num - df_num.mean()) / (df_num.max() - df_num.min()).fillna(0)

# Add Id and AnswerScore
df_num['Id'] = df_answer['Id_y']
df_num['AnswerScore'] = df_answer['Score']

# Export
df_num.to_csv(outFile,index=False)
print('Numeric dataset created.')

