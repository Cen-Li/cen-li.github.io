//Name:         Charles Nathan Duke
//Course:       CSCI 4250-001
//Instructor:   Dr. Cen Li
//Due:          9/12/2017
//File:         twoSquares.js
//Description:  Draws a 6-pointed star inside a circle

var gl, program;
var points;
var SIZE; 

function main() {
    var canvas = document.getElementById( "gl-canvas" );
    
    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { console.log( "WebGL isn't available" ); return; }

    // location of the center of the circle
	var center= vec2(0.0, 0.0);
	
    // radius of the outer circle
    var radius = 1.0;
    
    //Get the points for drawing
    var points = GeneratePoints(center, radius);
    points = points.concat(GeneratePolygon(center, radius));
    
    //Output to javascript console
	console.log("after generating points");
    console.log(points[102]);
    
    //  Configure WebGL
	gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 1.0, 1.0, 1.0, 1.0 );
    
    //  Load shaders and initialize attribute buffers
    program = initShaders( gl, "vertex-shader", "fragment-shader" );
    if (!program) { console.log("Failed to intialize shaders."); return; }
    gl.useProgram( program );
    
    // Load the data into the GPU
    var bufferId = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, bufferId );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(points), gl.STATIC_DRAW );

    // Associate out shader variables with our data buffer
    var vPosition = gl.getAttribLocation( program, "vPosition" );
    gl.vertexAttribPointer( vPosition, 2, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vPosition );
    
    render();
    
}

// generate points to draw a (non-solid) circle centered at 
//(center[0], center[1]) using GL_Line_STRIP
function GeneratePoints(center, radius) {
    var vertices=[];
	SIZE=100; // slices

	var angle = 2*Math.PI/SIZE;
	
    // Because LINE_STRIP is used in rendering, SIZE + 1 points are needed 
	// to draw SIZE line segments 
	for  (var i=0; i<SIZE+1; i++) {
	    console.log(i, "outer: ", center[0]+radius*Math.cos(i*angle), center[1]+radius*Math.sin(i*angle));
	    vertices.push([center[0]+radius*Math.cos(i*angle), 
		               center[1]+radius*Math.sin(i*angle)]);
	}

	return vertices;
}

function GeneratePolygon(center, radius) {
    var vertices=[];
	SIZE2=12; // slices

	var angle = 2*Math.PI/SIZE2;
	
    // Because LINE_STRIP is used in rendering, SIZE + 1 points are needed 
	// to draw SIZE line segments 
	for  (var i=0; i<SIZE2+1; i++) {
	    //console.log(i, "outer: ", center[0]+radius*Math.cos(i*angle), center[1]+radius*Math.sin(i*angle));
	    
        if (i % 2) {
        vertices.push([center[0]+radius*Math.cos(i*angle), 
		               center[1]+radius*Math.sin(i*angle)]);
        }
        else
        vertices.push([center[0]+ (radius/2) * Math.cos(i*angle), 
		               center[1]+ (radius/2) * Math.sin(i*angle)]);
	}
	
	return vertices;
}

function render() {
    gl.clear( gl.COLOR_BUFFER_BIT );
	// gl.uniform1i(gl.getUniformLocation(program, "colorIndex"), 1);
    //Draw the circle
    gl.drawArrays( gl.LINE_STRIP, 0, SIZE+1);
    //Draw the 6-pointed star
    gl.drawArrays( gl.LINE_STRIP, 101, 13);
}
