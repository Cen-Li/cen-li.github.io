Computer Graphics 4250 Final Project by Martina Nikic and Adam Curl

Files:

- draw.js: holds all functions that draw an object
- generate.js: holds all functions that generate vertices points or points within the pointsArray
- helper.js: contains all helper functions
- proj4.js: main js file that sets up the viewing area and renders objects
- proj4.html: front-end viewing of 3d objects
