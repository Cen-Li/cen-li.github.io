/***************************************************
  Note: Could not get the textures to work on Chrome
  but they work on Internet Explorer
****************************************************/

var canvas;
var gl;

var zoomFactor = 0.8;
var translateFactorX = 0.2;
var translateFactorY = 0.2;

var pointsArray = [];
var normalsArray = [];
var colors = [];

var left = -1;
var right = 1;
var ytop = 1;
var bottom = -1;
var near = -10;
var far = 10;
var deg = 5;
var eye=[.3, .4, .8];
var at=[0, 0, 0];
var up=[0, 1, 0];
var hole = 0;
var x = 0.75;
var y = 0.35;
var z = 0.35;
var iter = 1;
var texture1, texture2, texture3, texture4;
var phi = .3;  // camera rotating angles
var theta = .4;
var deg = .1;  // amount to change during user interative camera control
var Radius = 1.5;
var cubeCount =36;
sphereCount = 0;

var vertices = [
        vec4( -1, -1,  1, 1.0 ),
        vec4( -1,  1,  1, 1.0 ),
        vec4( 1,  1,  1, 1.0 ),
        vec4( 1, -1,  1, 1.0 ),
        vec4( -1, -1, -1, 1.0 ),
        vec4( -1,  1, -1, 1.0 ),
        vec4( 1,  1, -1, 1.0 ),
        vec4( 1, -1, -1, 1.0 )
    ];

var texCoordsArray = [];

// texture coordinates
var texCoord = [
        vec2(0, 0),
        vec2(0, 1),
        vec2(1, 1),
        vec2(1, 0),
    ];


var va = vec4(0.0, 0.0, -1.0,1);
var vb = vec4(0.0, 0.942809, 0.333333, 1);
var vc = vec4(-0.816497, -0.471405, 0.333333, 1);
var vd = vec4(0.816497, -0.471405, 0.333333,1);

var modelViewMatrix, projectionMatrix;
var modelViewMatrixLoc, projectionMatrixLoc;
var mvMatrixStack=[];

// light and material
var lightPosition = vec4(1, 1, 1, 0 );

var lightAmbient = vec4(0.3, 0.3, 0.3, 1.0 );
var lightDiffuse = vec4(.5, 0.5, 0.5, 1.0 );
var lightSpecular = vec4( .5, .5, .5, 1.0 );

var materialAmbient = vec4( .5, .5, .5, 1.0 );
var materialDiffuse = vec4( 0, 1, 0, 1.0);
var materialSpecular = vec4( 0, 1, 0, 1.0 );
var materialShininess = 40.0;

window.onload = function init()
{
    canvas = document.getElementById( "gl-canvas" );

    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }

    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 0.8, 0.8, 0.8, 1.0 );

    gl.enable(gl.DEPTH_TEST);

    //
    //  Load shaders and initialize attribute buffers
    //
    program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );

    // generate the points/normals
    colorCube();
    tetrahedron(va, vb, vc, vd, 5);
    hole = 1;
    tetrahedron(va, vb, vc, vd, 5);

    // pass data onto GPU
    var nBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, nBuffer);
    gl.bufferData( gl.ARRAY_BUFFER, flatten(normalsArray), gl.STATIC_DRAW );

    var vNormal = gl.getAttribLocation( program, "vNormal" );
    gl.vertexAttribPointer( vNormal, 3, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vNormal);

    var cBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, cBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(colors), gl.STATIC_DRAW );

    var vColor = gl.getAttribLocation( program, "vColor" );
    gl.vertexAttribPointer( vColor, 4, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vColor );

    var vBuffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, vBuffer);
    gl.bufferData(gl.ARRAY_BUFFER, flatten(pointsArray), gl.STATIC_DRAW);

    var vPosition = gl.getAttribLocation( program, "vPosition");
    gl.vertexAttribPointer(vPosition, 4, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);

    // set up texture buffer
    var tBuffer = gl.createBuffer();
    gl.bindBuffer( gl.ARRAY_BUFFER, tBuffer );
    gl.bufferData( gl.ARRAY_BUFFER, flatten(texCoordsArray), gl.STATIC_DRAW );

    var vTexCoord = gl.getAttribLocation( program, "vTexCoord" );
    gl.vertexAttribPointer( vTexCoord, 2, gl.FLOAT, false, 0, 0 );
    gl.enableVertexAttribArray( vTexCoord );

    modelViewMatrixLoc = gl.getUniformLocation( program, "modelViewMatrix" );
    projectionMatrixLoc = gl.getUniformLocation( program, "projectionMatrix" );

    EstablishTextures();
    //load textures
    loadTexture(texture2, gl.TEXTURE1);
    loadTexture(texture3, gl.TEXTURE2);
    loadTexture(texture4, gl.TEXTURE3);

    //setup lighting material
    SetupLightingMaterial();

    // support user interface
    document.getElementById("phiup").onclick=function(){phi += deg; render();};
    document.getElementById("phidown").onclick=function(){phi-= deg; render();};
    document.getElementById("thetaup").onclick=function(){theta+= deg; render();};
    document.getElementById("thetadown").onclick=function(){theta-= deg; render();};
    document.getElementById("zoomIn").onclick=function(){zoomFactor-= deg; render();};
    document.getElementById("zoomOut").onclick=function(){zoomFactor+= deg; render();};

    window.onkeydown = HandleKeyboard;

    render();
}

function HandleKeyboard(event)
{
    var key = String.fromCharCode(event.keyCode);
    switch( key ) {
      case 'A': shootBall();       //If user presses 'A' start animation
                break;
      case 'B': x = 0.75;         //If user presses 'B' reset scene
                y = 0.35;
                z = 0.35;
                iter = 1;
                phi = 0.3;
                theta = 0.4;
                zoomFactor = 0.8;
                render();
                break;
          };
}

function EstablishTextures()
{
    // ========  Establish Textures =================
    // --------create texture object 1----------
    texture1 = gl.createTexture();

    // create the image object
    texture1.image = new Image();

    // Enable texture unit 1
    gl.activeTexture(gl.TEXTURE0);

    // Tell the broswer to load an image
    texture1.image.src='hole.jpg';

    // register the event handler to be called on loading an image
    texture1.image.onload = function() {  loadTexture(texture1, gl.TEXTURE0); }

    // -------create texture object 2------------
    texture2 = gl.createTexture();

    // create the image object
    texture2.image = new Image();

    // Enable texture unit 1
    gl.activeTexture(gl.TEXTURE1);

    // Tell the broswer to load an image
    texture2.image.src='golfball1.jpg';


    // -------create texture object 3------------
    texture3 = gl.createTexture();

    // create the image object
    texture3.image = new Image();

    // Enable texture unit 1
    gl.activeTexture(gl.TEXTURE2);

    // Tell the broswer to load an image
    texture3.image.src='flag.jpg';


    // -------create texture object 4------------
    texture4 = gl.createTexture();

    // create the image object
    texture4.image = new Image();

    // Enable texture unit 1
    gl.activeTexture(gl.TEXTURE3);

    // Tell the broswer to load an image
    texture4.image.src='white.jpg';

}

function loadTexture(texture, whichTexture)
{
    // Flip the image's y axis
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);

    // Enable texture unit 1
    gl.activeTexture(whichTexture);

    // bind the texture object to the target
    gl.bindTexture( gl.TEXTURE_2D, texture);

    // set the texture image
    gl.texImage2D( gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, texture.image );

    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);

    // set the texture parameters
    gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri( gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);

}

function shootBall()    //function to animate golf ball
{
    iter += 5;
    x -= 0.1;
    z += 0.1;
    render();
    if(iter > 31)
    {
      x = 5;
      y = 5;
      z = 5;
      render();
      var sound = document.getElementById("applause");
      sound.play();         //plays applause sound effect
      return;
    }
    setTimeout(requestAnimFrame(shootBall), 3);
}

function SetupLightingMaterial()      //sets up lighting material
{
    // set up lighting and material
    ambientProduct = mult(lightAmbient, materialAmbient);
    diffuseProduct = mult(lightDiffuse, materialDiffuse);
    specularProduct = mult(lightSpecular, materialSpecular);

	// send lighting and material coefficient products to GPU
    gl.uniform4fv( gl.getUniformLocation(program, "ambientProduct"),flatten(ambientProduct) );
    gl.uniform4fv( gl.getUniformLocation(program, "diffuseProduct"),flatten(diffuseProduct) );
    gl.uniform4fv( gl.getUniformLocation(program, "specularProduct"),flatten(specularProduct) );
    gl.uniform4fv( gl.getUniformLocation(program, "lightPosition"),flatten(lightPosition) );
    gl.uniform1f( gl.getUniformLocation(program, "shininess"),materialShininess );
}

function quad(a, b, c, d) {

     	var t1 = subtract(vertices[b], vertices[a]);
     	var t2 = subtract(vertices[c], vertices[b]);
     	var normal = cross(t1, t2);
     	var normal = vec3(normal);
     	normal = normalize(normal);

     	pointsArray.push(vertices[a]);
      colors.push(vec4(0.133333, 0.545098, 0.133333, 1));
     	normalsArray.push(normal);
      texCoordsArray.push(texCoord[0]);

     	pointsArray.push(vertices[b]);
      colors.push(vec4(0.133333, 0.545098, 0.133333, 1));
     	normalsArray.push(normal);
      texCoordsArray.push(texCoord[1]);

     	pointsArray.push(vertices[c]);
      colors.push(vec4(0.133333, 0.545098, 0.133333, 1));
     	normalsArray.push(normal);
      texCoordsArray.push(texCoord[2]);

     	pointsArray.push(vertices[a]);
      colors.push(vec4(0.133333, 0.545098, 0.133333, 1));
     	normalsArray.push(normal);
      texCoordsArray.push(texCoord[0]);

     	pointsArray.push(vertices[c]);
      colors.push(vec4(0.133333, 0.545098, 0.133333, 1));
     	normalsArray.push(normal);
      texCoordsArray.push(texCoord[2]);

     	pointsArray.push(vertices[d]);
      colors.push(vec4(0.033333, 0.265098, 0.033333, 1));
     	normalsArray.push(normal);
      texCoordsArray.push(texCoord[3]);
}

function colorCube()
{
    	quad( 1, 0, 3, 2 );
    	quad( 2, 3, 7, 6 );
    	quad( 3, 0, 4, 7 );
    	quad( 6, 5, 1, 2 );
    	quad( 4, 5, 6, 7 );
    	quad( 5, 4, 0, 1 );
}

function DrawGround()
{

	mvMatrixStack.push(modelViewMatrix);

	var t=translate(0.45, 8*0.03, 0.6);
	var s=scale4(0.6, 0.03, 0.6);
  modelViewMatrix=mult(mult(modelViewMatrix, t), s);
	gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
	DrawSolidCube(1);

	modelViewMatrix=mvMatrixStack.pop();
}

function GenerateBall(a, b, c)
{
     normalsArray.push(vec3(a[0], a[1], a[2]));
     normalsArray.push(vec3(b[0], b[1], b[2]));
     normalsArray.push(vec3(c[0], c[1], c[2]));

     pointsArray.push(a);
     colors.push(vec4(1,1,1,1));
     pointsArray.push(b);
     colors.push(vec4(1,1,1,1));
     pointsArray.push(c);
     colors.push(vec4(1,1,1,1));

     texCoordsArray.push(texCoord[0]);
     texCoordsArray.push(texCoord[1]);
     texCoordsArray.push(texCoord[2]);

     sphereCount += 3;
}

function divideTriangle(a, b, c, count)
{
    if ( count > 0 )
    {
        var ab = mix( a, b, 0.5);
        var ac = mix( a, c, 0.5);
        var bc = mix( b, c, 0.5);

        ab = normalize(ab, true);
        ac = normalize(ac, true);
        bc = normalize(bc, true);

        divideTriangle( a, ab, ac, count - 1 );
        divideTriangle( ab, b, bc, count - 1 );
        divideTriangle( bc, c, ac, count - 1 );
        divideTriangle( ab, bc, ac, count - 1 );
    }
    else {
      if(hole == 0)
        GenerateBall( a, b, c );
      else if(hole == 1)
        GenerateHole(a, b, c);
    }
}

function tetrahedron(a, b, c, d, n) {
    	divideTriangle(a, b, c, n);
    	divideTriangle(d, c, b, n);
    	divideTriangle(a, d, b, n);
    	divideTriangle(a, c, d, n);
}

function DrawSolidSphere(radius)
{
	mvMatrixStack.push(modelViewMatrix);

	s=scale4(radius-0.045, radius-0.045, radius-0.045);
  modelViewMatrix = mult(modelViewMatrix, s);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));

 	// draw unit radius sphere
  for( var i=0; i<sphereCount; i+=3)
      gl.drawArrays( gl.TRIANGLES, cubeCount+i, 3 );

	modelViewMatrix=mvMatrixStack.pop();
}

function DrawHole(radius)
{
  mvMatrixStack.push(modelViewMatrix);

	s=scale4(radius-0.02, radius-0.02, radius-0.02);
  modelViewMatrix = mult(modelViewMatrix, s);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));

 	// draw unit radius sphere
  for( var i=0; i<sphereCount; i+=3)
      gl.drawArrays( gl.TRIANGLES, cubeCount+i+12324, 3 );

	modelViewMatrix=mvMatrixStack.pop();
}

function DrawSolidCube(length)
{
	mvMatrixStack.push(modelViewMatrix);
	s=scale4(length, length, length );
  modelViewMatrix = mult(modelViewMatrix, s);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));

  gl.drawArrays( gl.TRIANGLES, 0, 36);

	modelViewMatrix=mvMatrixStack.pop();
}

function scale4(a, b, c) {
   	var result = mat4();
   	result[0][0] = a;
   	result[1][1] = b;
   	result[2][2] = c;
   	return result;
}

function GenerateHole(a, b, c)
{
  normalsArray.push(vec3(a[0], a[1], a[2]));
  normalsArray.push(vec3(b[0], b[1], b[2]));
  normalsArray.push(vec3(c[0], c[1], c[2]));

  pointsArray.push(a);
  colors.push(vec4(0,0,0,1));
  pointsArray.push(b);
  colors.push(vec4(0,0,0,1));
  pointsArray.push(c);
  colors.push(vec4(0,0,0,1));

  texCoordsArray.push(texCoord[0]);
  texCoordsArray.push(texCoord[1]);
  texCoordsArray.push(texCoord[2]);

  sphereCount += 3;
}

function DrawFlag()
{
  var t;

	mvMatrixStack.push(modelViewMatrix);
  gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 2);  // start using texture
  gl.uniform1i(gl.getUniformLocation(program, "texture"), 3);  // fragment shader to use gl.TEXTURE3
	t=translate(-0.25, 0.5, 0.38);
	var s=scale4(0.01, 0.5, 0.01);
  modelViewMatrix=mult(mult(modelViewMatrix, t), s);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  DrawSolidCube(1);   //Draw Flag Pole
  gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 1);  // stop using texture

  modelViewMatrix=mvMatrixStack.pop();

  gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 2);  // start using texture
  gl.uniform1i(gl.getUniformLocation(program, "texture"), 2);  // fragment shader to use gl.TEXTURE2
  mvMatrixStack.push(modelViewMatrix);
	t=translate(-0.078, 1.02, 0.6);
	var r=rotate(90, 1, 0, 0);
	var s=scale4(0.1, 0.008, 0.08);
  modelViewMatrix=mult(mult(mult(modelViewMatrix, t), r), s);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  DrawSolidCube(1);   //Draw Flag
  gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 1);  // stop using texture
  modelViewMatrix = mvMatrixStack.pop();

}

function render()
{
	var t;
	gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

	// set up view and projection
  projectionMatrix = ortho(left*zoomFactor-translateFactorX, right*zoomFactor-translateFactorX, bottom*zoomFactor-translateFactorY, ytop*zoomFactor-translateFactorY, near, far);
  eye=vec3(phi, theta, 0.8 );  //define eye position based on values of phi and theta
  modelViewMatrix=lookAt(eye, at, up);

  gl.uniformMatrix4fv(projectionMatrixLoc, false, flatten(projectionMatrix));
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));

	mvMatrixStack.push(modelViewMatrix);

	t=translate(x, y, z);
  modelViewMatrix=mult(modelViewMatrix, t);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 2);  // start using texture
  gl.uniform1i(gl.getUniformLocation(program, "texture"), 1);  // fragment shader to use gl.TEXTURE1
	DrawSolidSphere(0.1);      //Draw Golf Ball
  gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 1);  // stop using texture

	modelViewMatrix=mvMatrixStack.pop();

  DrawGround();     //Draw Ground

  mvMatrixStack.push(modelViewMatrix);

	t=translate(0.1, 0.35, 1);
  modelViewMatrix=mult(modelViewMatrix, t);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 2);  // start using texture
  gl.uniform1i(gl.getUniformLocation(program, "texture"), 0);  // fragment shader to use gl.TEXTURE0
	DrawHole(0.1);         //Draw Hole
  gl.uniform1i(gl.getUniformLocation(program, "textureFlag"), 1);  // stop using texture

	modelViewMatrix=mvMatrixStack.pop();

  mvMatrixStack.push(modelViewMatrix);
  t= translate(0.25, 0, 0.25);
  modelViewMatrix = mult(modelViewMatrix, t);
  gl.uniformMatrix4fv(modelViewMatrixLoc, false, flatten(modelViewMatrix));
  DrawFlag();     //Draw Flag

  modelViewMatrix=mvMatrixStack.pop();

}
