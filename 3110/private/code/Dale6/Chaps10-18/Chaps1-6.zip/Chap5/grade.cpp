// Program Grade prints appropriate messages based on a
// grade read from the keyboard.

#include <iostream>
using namespace std;

int main ()
{
  int grade;

  cout << "Enter an integer grade between 50 and 100."
       << "  Press return. " << endl;
  cin >> grade;

  if  /* TO BE FILLED IN  */
  cout << "Congratulations!" << endl;
  return 0;
}                           
