// Program Temperature reads in a temperature and prints an
// appropriate message.

#include <iostream>
using namespace std;

int main ()
{
  int  temperature;

  cout << "Enter the temperature in your room." << endl;
  cin >> temperature;
  
  /* TO BE FILLED IN */
  return 0;
}
