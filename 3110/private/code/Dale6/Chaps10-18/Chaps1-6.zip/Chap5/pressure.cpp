// Program Pressureprints appropriate messages based on
// a pressure reading input from the keyboard.

#include <iostream>
using namespace std;
 
main ()
{
  int  pressure;

  cout << "Enter an integer pressure reading. "
       << " Press Return."  << endl;
  cin >> pressure;
  /* FILL IN Code appropriate to exercise */ 
  return 0;
}
