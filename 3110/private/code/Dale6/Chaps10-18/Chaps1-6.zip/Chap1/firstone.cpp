// This program prints my name on the screen.
#include <iostream>
using namespace std;

int main()
{
  cout <<"**********************" <<endl;
  cout <<"My name is ";
  cout <<"Nell Dale" <<endl;
  cout <<"*********************" <<endl;
  return 0;
}