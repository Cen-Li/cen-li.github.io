// Program Error prints 4 lines on the screen.
#include <iostream>
using namespace std;

int main()
{
  cout <<"This program demonstrates " <<endl;
  cout <<"how a missing semicolon can "

  cout <<"cause a problem." <<endl;
  cout <<"*********************" <<endl;
  return 0;
}
