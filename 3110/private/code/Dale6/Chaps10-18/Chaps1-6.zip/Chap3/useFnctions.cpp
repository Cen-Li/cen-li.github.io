// Program UseFunctions demonstrates the use of library and
// user-defined functions.

#include <iostream>
#include <cmath>
using namespace std;

float Answer(float, float, float);

int main ()
{
  cout  << fixed  << showpoint;

  cout  << Answer(______, ______, _______);
  return 0;
}

float Answer(float one, float two, float three)
{
  return ((- two + sqrt(pow(two, _____) 
      - (4.0 * one * three))) / (2.0 * one));
}


