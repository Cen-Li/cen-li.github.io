// Program Greet prints a greeting on the screen.

#_________
#_________
using namespace std;

_________ string FIRST_NAME = "Sarah";
_________ string LAST_NAME = "Sunshine";
_____  _______ ()
{
  _______ message;
  _______ name;

  name = FIRST_NAME + ' ' + LAST_NAME;
  message = "Good morning " __________  name + '.';
  cout  << message  _______ endl;
  _______ 0;
}

