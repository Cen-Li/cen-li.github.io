// Program Pressure prints appropriate messages based
// on a pressure reading read from a file.  Processing
// continues until the plant is evacuated because of
// a pressure reading over 100. 

#include <iostream>
#include <fstream>
using namespace std;

int main ()
{
  int  pressure;
  ifstream  data;
  data.open("Shell3.D1");
                                          
  /* LOOP TO BE FILLED IN */

    data  >> pressure;                                        
                                                            
    /* FILL IN Code to print the message */

    returm 0;
}                                                                               

