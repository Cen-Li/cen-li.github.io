// Program SumDigits prompts for and reads a one-digit number.
// Values between 0 and the digit (inclusive) are summed.

#include <iostream>
using namespace std;

int main ()
{
  int counter;	// Loop-control variable
  int sum;		// Running sum
  int digit;

  cout << "Enter a one-digit number; press return."
       << endl;
  cin >> digit;
  counter =  /* TO BE FILLED IN */                          
  sum  =     /* TO BE FILLED IN */                          

  while /* TO BE FILLED IN  */                                                   
  {                                                       
    /*  TO BE FILLED IN */                               
  }
  cout << "Sum of digits between 0 and "
       << digit  << " is "  << sum  << endl;
  return 0;
}
