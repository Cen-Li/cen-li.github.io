// Program CountUC counts the number of uppercase letters
// on a line.

#include <iostream>
using namespace std;

int main ()
{  
  char letter;
  int  letterCt;

  /* TO BE FILLED IN */
  return 0;
}
