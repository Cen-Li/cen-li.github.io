/*----------------------------------------------------------------------
  File    : vecops.h
  Contents: some special vector operations
  Author  : Christian Borgelt
  History : 16.09.1996 file created
            04.02.1999 long int changed to int
----------------------------------------------------------------------*/
#ifndef __VECOPS__
#define __VECOPS__

/*----------------------------------------------------------------------
  Type Definitions
----------------------------------------------------------------------*/
typedef int VCMPFN (const void *p1, const void *p2, void *data);

/*----------------------------------------------------------------------
  Functions
----------------------------------------------------------------------*/
extern void v_sort (void *vec, int n, VCMPFN cmpfn, void *data);
extern void v_move (void *vec, int offs, int n, int pos, int esz);

#endif
